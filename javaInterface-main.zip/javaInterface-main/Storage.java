public class Storage {
    String type = "SSD";
    String manufacturer = "samsung";
    int capacity = 512;

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "storage";
    }
}
