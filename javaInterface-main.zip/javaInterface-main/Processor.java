public class Processor {
    String type = "core i5";
    int numberOfCores = 2;

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "processor";
    }
}
